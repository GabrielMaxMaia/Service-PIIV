package com.example.services;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServicesApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServicesApiApplication.class, args);
	}

}
